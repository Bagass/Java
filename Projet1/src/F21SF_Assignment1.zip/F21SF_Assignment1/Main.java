package F21SF_Assignment1;

public class Main {

	public static void main(String[] args) {
		// Create a HotelRoomManager
		HotelRoomManager manager = new HotelRoomManager();
		// Launch the program
		manager.run();
	}

}
