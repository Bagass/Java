package F21SF_Assignment1;

public class HotelRoomManager {
	private HotelRoomList allHotelRooms;

	// Constructor of HotelRoomManager, create an empty list of HotelRoom
	public HotelRoomManager() {
		allHotelRooms = new HotelRoomList();
	}

	public void run() {
		// Read the file in parameter and fulfill our list with the data
		allHotelRooms.readFile("HotelRoomList.csv");
		String report = allHotelRooms.getTableOfHotelRooms();
		// Print the details of all the hotel rooms of our list formatted into a
		// table
		System.out.println(report);
		//Write into a text file the report and statistics of our HotelRoomList
		allHotelRooms.writeToFile("HotelRoomOut.txt", allHotelRooms);
	}
}
